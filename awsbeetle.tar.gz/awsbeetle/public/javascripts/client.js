// alert("Welcome to the AWS Beetle Dashboard");

/* btnRefresh = function(){

ec2.describeInstances(function(err,data){
  if(err) console.log(err);
  else
    instances = [];
    images = [];
    keys = [];
    for(i in data.Reservations)
      for (ii in data.Reservations[i].Instances)
        
        instanceid = data.Reservations[i].Instances[ii].InstanceId;
        imageid = data.Reservations[i].Instances[ii].ImageId;
        keyname = data.Reservations[i].Instances[ii].KeyName;
        instances.push(instanceid);
        images.push(imageid);
        keys.push(keyname);       
  });

ec2.describeInstanceStatus(function(err,data){
  if (err) console.log(err);
  else
      for (i in data.InstanceStatuses)
      status = data.InstanceStatuses[i].InstanceStatus.Status;
      critical = data.InstanceStatuses[i].InstanceState.Name;
      console.log(status,critical);
});
} */

function timeNow(){
	document.write(Date.now());
}

function btnRefresh(){
	
}