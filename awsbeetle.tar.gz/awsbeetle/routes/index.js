var express = require('express');
var router = express.Router();
var aws = require('aws-sdk');

aws.config.update({region: 'us-west-2'});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', {title: 'The FINRA Beetle'})
  //res.send('Paragraph');

});











module.exports = router;
